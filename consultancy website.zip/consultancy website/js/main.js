(function ($) {
    "use strict";

    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 40) {
            $('.navbar').addClass('sticky-top');
        } else {
            $('.navbar').removeClass('sticky-top');
        }
    });
    
    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
    });
    
})(jQuery);

document.addEventListener("DOMContentLoaded", function () {
    const sections = document.querySelectorAll("#about-section, #service-section, #quote-section, #contact-section");

    // Intersection Observer to handle scroll effects
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("show"); // Add show class when in view
            } else {
                entry.target.classList.remove("show"); // Remove class when out of view (optional)
            }
        });
    }, { threshold: 0.2 }); // Trigger when 20% of section is visible

    sections.forEach(section => {
        observer.observe(section);
    });

    // Initial fade-in effect on page load
    setTimeout(() => {
        sections.forEach(section => section.classList.add("show"));
    }, 500);
});
document.addEventListener("DOMContentLoaded", function () {
    const serviceSection = document.querySelector("#service-section");

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                serviceSection.classList.add("show"); // Trigger animation
            }
        });
    }, { threshold: 0.2 });

    observer.observe(serviceSection);
});
document.addEventListener("DOMContentLoaded", function () {
    const aboutSection = document.querySelector("#about-section");

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                aboutSection.classList.add("show"); // Trigger animation
            }
        });
    }, { threshold: 0.2 });

    observer.observe(aboutSection);
});
document.addEventListener("DOMContentLoaded", function () {
    const services = document.querySelectorAll(".service-item");

    function revealOnScroll() {
        services.forEach((service, index) => {
            const serviceTop = service.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;

            if (serviceTop < windowHeight - 50) {
                service.classList.add("show");
            }
        });
    }

    window.addEventListener("scroll", revealOnScroll);
    revealOnScroll(); // Initial check in case elements are already in view
});
//CHAT BOT
 document.addEventListener("DOMContentLoaded", function() {
    var script1 = document.createElement('script');
    script1.src = 'https://cdn.botpress.cloud/webchat/v2.2/inject.js';
    script1.defer = true;
    document.body.appendChild(script1);

    var script2 = document.createElement('script');
    script2.src = 'https://files.bpcontent.cloud/2025/02/20/09/20250220092117-W6D5783G.js';
    script2.defer = true;
    document.body.appendChild(script2);
  });
  
  //NEWS API 
  const API_KEY = 'pub_67425be1e5416e38ff9e2fa35eafbaca83998';

async function fetchNews() {
    try {
        const response = await fetch(`https://newsdata.io/api/1/news?category=business&q=kenya&apikey=${API_KEY}`);
        const data = await response.json();
        
        if (data.status === 'success') {
            // Limit the results to 3 articles and filter out those without images
            const filteredArticles = data.results.filter(article => article.image_url);
            displayNews(filteredArticles.slice(0, 3));
        }
    } catch (error) {
        console.error('Error fetching news:', error);
    }
}

function displayNews(articles) {
    const blogPosts = document.getElementById('blogPosts');
    let postsHTML = '';

    articles.forEach(article => {
        postsHTML += `
            <div class="col-lg-4">
                <div class="card h-100">
                    <img src="${article.image_url}" 
                         class="card-img-top" 
                         alt="${article.title}" 
                         style="height: 250px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">${article.title}</h5>
                        <p class="card-text">${article.description || ''}</p>
                    </div>
                    <div class="card-footer bg-white">
                        <a href="${article.link}" 
                           class="btn btn-primary" 
                           target="_blank" 
                           rel="noopener noreferrer">
                            Read More
                        </a>
                        <small class="text-muted ms-3">${new Date(article.pubDate).toLocaleDateString()}</small>
                    </div>
                </div>
            </div>
        `;
    });

    blogPosts.innerHTML = postsHTML;
}

// Fetch news when page loads
fetchNews();
// prompt chat bot
document.addEventListener("DOMContentLoaded", function() {
    // Injecting the chatbot scripts
    var script1 = document.createElement('script');
    script1.src = 'https://cdn.botpress.cloud/webchat/v2.2/inject.js';
    script1.defer = true;
    document.body.appendChild(script1);

    var script2 = document.createElement('script');
    script2.src = 'https://files.bpcontent.cloud/2025/02/20/09/20250220092117-W6D5783G.js';
    script2.defer = true;
    document.body.appendChild(script2);

    // Adding event listener to open chatbot when FAQ link is clicked
    document.getElementById('faqLink').addEventListener('click', function(event) {
      event.preventDefault(); // Prevent default link behavior
      // Triggering the chatbot to open
      window.BotpressWebChat.open();
    });
  });