(function ($) {
    "use strict";

    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 40) {
            $('.navbar').addClass('sticky-top');
        } else {
            $('.navbar').removeClass('sticky-top');
        }
    });
    
    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
    });
    
})(jQuery);

document.addEventListener("DOMContentLoaded", function () {
    const sections = document.querySelectorAll("#about-section, #service-section, #quote-section, #contact-section");

    // Intersection Observer to handle scroll effects
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("show"); // Add show class when in view
            } else {
                entry.target.classList.remove("show"); // Remove class when out of view (optional)
            }
        });
    }, { threshold: 0.2 }); // Trigger when 20% of section is visible

    sections.forEach(section => {
        observer.observe(section);
    });

    // Initial fade-in effect on page load
    setTimeout(() => {
        sections.forEach(section => section.classList.add("show"));
    }, 500);
});
document.addEventListener("DOMContentLoaded", function () {
    const serviceSection = document.querySelector("#service-section");

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                serviceSection.classList.add("show"); // Trigger animation
            }
        });
    }, { threshold: 0.2 });

    observer.observe(serviceSection);
});
document.addEventListener("DOMContentLoaded", function () {
    const aboutSection = document.querySelector("#about-section");

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                aboutSection.classList.add("show"); // Trigger animation
            }
        });
    }, { threshold: 0.2 });

    observer.observe(aboutSection);
});
document.addEventListener("DOMContentLoaded", function() {
    var script1 = document.createElement('script');
    script1.src = 'https://cdn.botpress.cloud/webchat/v2.2/inject.js';
    script1.defer = true;
    document.body.appendChild(script1);

    var script2 = document.createElement('script');
    script2.src = 'https://files.bpcontent.cloud/2025/02/20/09/20250220092117-W6D5783G.js';
    script2.defer = true;
    document.body.appendChild(script2);
  });