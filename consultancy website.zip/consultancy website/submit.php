<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$messageType = '';
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = htmlspecialchars($_POST['fullname']);
    $email = htmlspecialchars($_POST['email']);
    $service = htmlspecialchars($_POST['service']);
    $user_message = htmlspecialchars($_POST['message']);

    try {
        $mail = new PHPMailer(true);
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'mail.empowergrowth.co.ke';
        $mail->SMTPAuth = true;
        $mail->Username = 'Info@empowergrowth.co.ke';
        $mail->Password = 'Mn@EG12!';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        // Email content
        $mail->setFrom($email, $full_name);
        $mail->addAddress('Info@empowergrowth.co.ke');
        $mail->isHTML(true);
        $mail->Subject = "New Inquiry: $service";
        $mail->Body = "<html>
            <body>
                <h2>New Contact Form Submission</h2>
                <p><strong>Name:</strong> $full_name</p>
                <p><strong>Email:</strong> $email</p>
                <p><strong>Service:</strong> $service</p>
                <p><strong>Message:</strong><br>" . nl2br($user_message) . "</p>
            </body>
        </html>";

        $mail->send();
        $messageType = 'success';
        $message = 'Thank you for your inquiry. We will get back to you soon!';
    } catch (Exception $e) {
        $messageType = 'error';
        $message = 'There was an error sending your inquiry. Please try again later.';
    }
}
?>

<?php
// ... [Keep the PHP processing code the same as before] ...
?>

<?php
// ... [Keep the PHP processing code the same as before] ...
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - EmpowerGrowth</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* Existing message box styles removed for simplicity */
        body { margin: 0; font-family: Arial, sans-serif; }
    </style>
</head>
<body>

<!-- Contact Section --> 
<!-- ... [Keep the contact form the same as before] ... -->

<!-- Message Box -->
<?php if(isset($messageType) && isset($message)): ?>
<script>
    // Display the alert message and navigate back to the previous page after "OK"
    alert("<?php echo $messageType == 'success' ? 'Success!' : 'Error!'; ?>\n\n<?php echo $message; ?>");
    window.history.back();  // Take the user back to the previous page
</script>
<?php endif; ?>

</body>
</html>
